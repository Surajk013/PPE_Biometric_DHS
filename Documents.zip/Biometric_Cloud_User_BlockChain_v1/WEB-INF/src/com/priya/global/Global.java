/**
 * 
 */
package com.priya.global;

/**
 * @author 
 *Jan 16, 2012 12:50:11 PM
 *Project:-E_Gov
 *Package:-com.nitin.global
 *File:-Global.java
 */
public interface Global 
{
	public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";	
	public static final String JDBC_HOST_URL_WITH_DBNAME = "jdbc:mysql://localhost:3306/db_biometric_blockchain";
	public static final String DATABASE_USERNAME = "root";
	public static final String DATABASE_PASSWORD = "admin";
	public static final String STATUS = "valid";
	public static final String TRUE = "yes";
}
